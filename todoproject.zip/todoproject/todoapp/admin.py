from django.contrib import admin
from . import models

class TodoItemAdmin(admin.ModelAdmin):
    pass
admin.site.register(models.TodoItem, TodoItemAdmin)
