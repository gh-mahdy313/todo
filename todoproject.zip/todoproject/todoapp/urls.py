from django.urls import path
from . import views

app_name= "todoapp"

urlpatterns = [
    path('', views.home_view, name='home'),
    path('list/', views.todo_list_view, name='list'),
    path('create/', views.todo_item_create, name='create'),
    path('<id>/delete/', views.todo_item_delete, name='delete'),
]
