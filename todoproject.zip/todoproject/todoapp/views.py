from django.shortcuts import render, redirect
from .models import TodoItem
from django.contrib.auth.decorators import login_required
from .forms import TodoItemForm

def home_view(request):
    return render(request, 'todoapp/home.html')


@login_required(login_url='/accounts/login')
def todo_list_view(request):
    user = request.user
    query = TodoItem.objects.filter(owner = user)
    if request.method == 'POST':
        checked_list = request.POST.getlist('checked')
        checked_list = [int(i) for i in checked_list]
        for todo_item in query:
            if todo_item.id in checked_list:
                TodoItem.objects.filter(id = todo_item.id).update(checked = True)
            else:
                TodoItem.objects.filter(id = todo_item.id).update(checked = False)
        return redirect('/list')

    length = len(query)
    return render(request, 'todoapp/todo_list.html', {'todoList':query, 'len':length})

@login_required(login_url='/accounts/login')
def todo_item_create(request):
    user = request.user
    form = TodoItemForm()
    if request.method == 'POST':
        form = TodoItemForm(request.POST)
        if form.is_valid():
            var = form.save(commit= False)
            var.owner = user
            var.save()
            return redirect('todoapp:list')
        else:
            return redirect('todoapp:list')

    return render(request, 'todoapp/todo_item_create.html', {'form':form})

@login_required(login_url='/accounts/login')
def todo_item_delete(request, id):
    try:
        item = TodoItem.objects.get(id = id)
    except:
        return redirect('/list')
    if item.owner == request.user:
        item.delete()
        return redirect('/list')
    else:
        return redirect('/list')
